<?php
// Get the DB connection
require_once 'database.php';

// Get all registered users from the visitors.registration table
$query = 'SELECT * FROM registration';
$statement = $db->prepare($query);
$statement->execute();
$users = $statement->fetchAll();
$statement->closeCursor();
//var_dump($users);
//exit;

// If there are registered users display them in the main element below


// If there are no registered users, display the 'Nothing to see here paragraph'


?>
	<!doctype html>
	<html>

	<head>
		<meta charset="UTF-8">
		<title>Home | M-V-C Demo</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>

	<body>
		<header>
			<h1>M-V-C Demo</h1>
			<div id="tools"><a href="registration.php" title="Go to the registration page">Register</a> </div>
		</header>
		<main>
			<h1>Home Page</h1>
			<?php
				if(!empty($users)){
					$list = '<ul>';
					foreach ($users as $user) {
						$list .= "<li>{$user['regFirstName']} {$user['regLastName']}"
						. " <a href='update_proccess.php?id={$user['regId']}' title='Edit {$user['regFirstName']}'>Edit</a>"
							. " <a href='delete_proccess.php?id={$user['regId']}' title='Delete {$user['regFirstName']}'>Delete</a>"
								. "</li>";
					}

					$list .= '</ul>';
					echo $list;
				} else {

		echo "<p>Nothing to see here. Why don't your register?</p>";

				}
				?>
		</main>
		<footer>
			<small>For review only</small>
		</footer>
	</body>

	</html>
